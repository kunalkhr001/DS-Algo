#include<iostream>
using namespace std;

int main(){

	int a = 5;
	int b = 10;
	double d =  5.0 / 10;
	cout << d << endl;
/*	double a = 10.5;
	cout << a << endl;
	int b = 20;
//	cout << (a + b ) << endl;

	int c = a + b;
	cout << c << endl;
*/

}

