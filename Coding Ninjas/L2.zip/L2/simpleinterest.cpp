#include<iostream>
using namespace std;

int main(){

	// Sample Program

	char ch = 'a';
	
	double d = 10.5;
/*
	float f = 10.5;
	
	bool b = true; 
	b = 0;   // false
	b = 1; // true - any non zero integer
	b = false;*/

	//int p = 1000;
//	p = 2000;
//	cout << p << endl;

//	p = 1000;

	int p, r, t;
//	int r;
//	int t;
	cin >> p  >> r >> t;
	//cin >> r;
	//cin >> t;

	int si = (p * r * t) / 100;
	cout << si << endl;
	//cout << endl;

}

