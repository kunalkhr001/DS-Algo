#include<iostream>
using namespace std;

int main(){

	int n;
	cin >> n;
	int count = 1;
	int num;
	while(count <= n){
		cin >> num;
		cout << num << endl;
		count = count + 1;
	}
	cout << num << endl;
}

