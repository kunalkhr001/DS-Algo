#include<iostream>
using namespace std;

int main(){

	int a = 10;
	int b = 20;
	if(++a > 10 || ++b > 20){
		cout << "Inside if " << endl;
	}else{
		cout << "Inside else " << endl;
	}
	cout << "a: " << a << endl;	
	cout << "b: " << b << endl;	
	//a = a + 1; 
	/*int b = --a ;//, ++a
	cout << "a: " << a << endl;
	cout << b << endl;
	*/
	
	}

