#include<iostream>
using namespace std;

int main(){

	char ch;
	int count = 0;
	cin.get(ch);
	while(ch != '$'){
			count++;
			//cin >> ch;
			cin.get(ch);
	}
	cout << "count " << count << endl;
}

