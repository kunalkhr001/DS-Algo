#include<iostream>
#include<climits>
using namespace std;

int factorial(int n){	
	int fact = 1;
	int i = 1;
	while(i <= n){
		fact = fact*i;
		i++;
	}
	return fact;
}
void  ncr(int n, int r){
  int factN	=  factorial(n); 
	int factR =  factorial(r);
	int factNR = factorial(n - r);
	int ans = factN / (factR * factNR) ;
	cout << ans << endl;
	//return ans;
//	return;
}

void print(int n){
	int i = 1;
	while(i <= n){
		if(i == 3){
			return;
		}
		cout << i << endl;
		i++;
	}
	cout << "Inside print " << endl;
}

void increment(int a){
	a++;
	//return a;
}

int main(){
	int a = 10;
	increment(a);
	//	cout <<  increment(a) << endl;
	cout << a << endl;
	
	/*cout << "Inside Main before print  " << endl;
	print(4);
	cout << "Inside Main after print " << endl;
*/
	//int a = INT_MAX; // 2^31 - 1	
/*	int n, r;
	cin >> n;
	cin >> r;
	ncr(n,r);
	cout << ans << endl;
*/


	/*	int factN = 1;
	int i = 1;
	while(i <= n){
		factN = factN*i;
		i++;
	}
	int factR = 1;
	 i = 1;
	while(i <= r){
		factR = factR * i;
		i++;
	}	
	int factNR = 1;
	 i = 1;
	while(i <= n - r){
		factNR = factNR*i;
		i++;
	}*/



}

