#include<iostream>
using namespace std;

int main(){

	bool b = -10;
	cout << b << endl;

	/*int a = 10;
	char ch1 = 'a';
	a = ch1 + 1;
	char ch2 = a;
	cout << ch2  << endl;
	*/
	/*int b = a + 0.5;
	double c = a + 0.5;
	cout << b << endl;
	cout << c <<endl;
*/

}

