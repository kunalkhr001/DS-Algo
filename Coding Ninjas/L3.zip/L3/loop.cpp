#include<iostream>
using namespace std;

int main(){
	
	int a = 6 / (6 + 2);
	cout << a << endl;
	int i = 1;  // initialise
	int n = 5;
/*	while(i <= n){
		if(i == 3){
			//cout << i << endl;
			i = i + 1;
			continue;
		}
		cout << i << endl;
		i = i + 1;
	}
*/
	/*for(int i = 1; i <= n;i = i + 1){
		if(i == 3){
		//	cout << i << endl;
			continue;
		}
		cout << i << endl;
		 //i = i + 1;
	}
*/

	/*	while(i <= n){
		int j = 1;
		while(j <= n){
			cout << "*";
			if(j == i){
				break;
			}
			j = j + 1;
		}
		cout << endl;
		i = i + 1;
	}
*/
	/*	while(i < 5){ // condition
		if(i == 3){
				break;
		}
		cout << i << endl;
		i = i + 1;  // increment
	}*/
	cout << "Outside While " << endl;

	/*
	// for loop
	for(int a = 1; a < 5; a = a + 1){
			
		cout << a << endl;

	}
	*/
/*
	int a = 1;
	for(;a < 5;){
		a = a + 1;
	}
*/







}

