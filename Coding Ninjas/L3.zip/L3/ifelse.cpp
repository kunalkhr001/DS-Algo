#include<iostream>
using namespace std;

int main(){

	int n = 1;
//	double n = 11.1;
//	cout << n << endl;
		int a = 10;
	while(n < 5){
		cout << a << endl;
		a = a + 1;
		n = n + 1;
	}



	/*
	if(n > 10){
		int n = 16;
		cout << n << endl;
		cout << "Inside if 1" << endl;
	}
	else if(n < 10){
		cout << "Inside if 2" << endl;
	}
	else{
		cout << "Inside else 2" << endl;
	}
*/

}

