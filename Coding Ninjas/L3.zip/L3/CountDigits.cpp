#include<iostream>
using namespace std;

int main(){

	int num;
	cin >> num;
	int temp = num;
	int count = 0;
	int reverse = 0;
	while(temp > 0){
		int lastDigit = temp % 10;
//		cout << lastDigit ;
		reverse = reverse * 10 + lastDigit;
		temp = temp / 10;
		count = count + 1;
	}
	cout << reverse << endl;
	//	cout << "Number of digits in " << num << " " << count << endl;
}

