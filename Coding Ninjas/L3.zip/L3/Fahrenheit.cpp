#include<iostream>
using namespace std;

int main(){


	int startValue, endValue, stepSize;
	cin >> startValue >> endValue  >> stepSize;
	int fahrenheitValue = startValue;

	while(fahrenheitValue <= endValue){
		int celsiusValue = (5.0/9) * (fahrenheitValue - 32);
		cout << fahrenheitValue << " " << celsiusValue << endl;
		fahrenheitValue = fahrenheitValue + stepSize;
	//	fahrenheitValue += stepSize;
	}

}

